import paho.mqtt.client as mqtt
import json
from decoders.thermokon_decoder import Decode

BROKER = "127.0.0.1"
PORT = 1883
INPUT_TOPIC = "application/Thermokon/device/+/rx"
OUTPUT_TOPIC_PREFIX = "application/decoded/"

def on_message(client, userdata, msg):
    print(f"[MQTT] Message received on {msg.topic}: {msg.payload.decode(errors='ignore')}")
    try:
        # Parse the raw message
        payload = json.loads(msg.payload.decode("utf-8", errors='ignore'))
        dev_eui = payload.get("devEUI", "unknown")
        f_port = payload.get("fPort", 0)
        data_hex = payload.get("data", "")
        data_bytes = bytes.fromhex(data_hex)

        # Decode the data using your Thermokon decoder
        decoded_data = Decode(f_port, data_bytes)

        # Prepare the output topic and payload
        output_topic = f"{OUTPUT_TOPIC_PREFIX}{dev_eui}"
        output_payload = {
            "devEUI": dev_eui,
            "decoded_data": decoded_data
        }

        # Publish the decoded data
        client.publish(output_topic, json.dumps(output_payload))
        print(f"[MQTT] Decoded data published to {output_topic}: {output_payload}")

    except Exception as e:
        print(f"[ERROR] Exception while processing message: {e}")

def main():
    # Create the MQTT client
    client = mqtt.Client()
    client.on_message = on_message

    # Connect and subscribe
    client.connect(BROKER, PORT, 60)
    client.subscribe(INPUT_TOPIC)
    print(f"[MQTT] Subscribed to topic: {INPUT_TOPIC}")

    # Start the blocking loop
    client.loop_forever()

if __name__ == "__main__":
    main()
